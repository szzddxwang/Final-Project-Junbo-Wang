"""Rebuild the downloadable module source outside the original H-drive workspace."""
from pathlib import Path
import subprocess,zipfile
R=Path(__file__).resolve().parent;B=R/'build-output';B.mkdir(exist_ok=True)
esbuild=R/'tools/programmable_simulator/node_modules/esbuild/bin/esbuild'
if not esbuild.exists():raise SystemExit('First run npm ci in tools/programmable_simulator (pinned lockfile).')
for entry,name,extra in [('editor.mjs','editor.js',['--global-name=ProgrammableLib']),('worker.mjs','worker.js',[])]:
 subprocess.run(['node',str(esbuild),str(R/'src/programmable_circuit'/entry),'--bundle','--format=iife','--target=es2020','--legal-comments=inline','--outfile='+str(B/name),*extra],cwd=R,check=True)
for ext in ['js','mjs']:
 p=R/'widget'/('LearningWorkspace.'+ext);s=p.read_text(encoding='utf8')
 a=s.index('var ProgrammableLib =');b=s.index('function labLedResistor',a)
 s=s[:a]+(B/'editor.js').read_text(encoding='utf8')+'\n'+s[b:]
 (B/p.name).write_text(s,encoding='utf8');subprocess.run(['node','--check',str(B/p.name)],check=True)
with zipfile.ZipFile(R/'widget/LearningWorkspace.template.mpk')as old,zipfile.ZipFile(B/'LearningWorkspace.mpk','w',zipfile.ZIP_DEFLATED)as new:
 for i in old.infolist():
  p=B/Path(i.filename).name;new.writestr(i,p.read_bytes()if p.name in ['LearningWorkspace.js','LearningWorkspace.mjs']else old.read(i.filename))
print('Rebuilt worker.js and native widget in build-output. Install only in a stopped, backed-up project.')
