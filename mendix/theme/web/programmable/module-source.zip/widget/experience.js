// Original small teaching diagrams. Decorative: the adjacent text gives the meaning.
function LearningSubjectIcon({system='LED_GPIO'}) {
 const h=React.createElement,paths={
  ANALOG_ADC:'M5 37 L43 9 M5 37 H14 V30 H23 V23 H32 V16 H43',
  DIGITAL_INPUT:'M5 30 H17 M31 30 H43 M17 30 L30 18 M17 34 V38 M31 34 V38',
  LED_GPIO:'M5 25 H16 M32 25 H43 M16 16 L32 25 L16 34 Z M32 15 V35 M30 10 L37 3 M35 15 L43 7',
  I2C_SENSOR:'M5 16 H43 M5 32 H43 M14 16 V32 M34 16 V32 M21 23 H27',
  UART_DEVICE:'M4 14 H40 L34 8 M40 14 L34 20 M44 34 H8 L14 28 M8 34 L14 40',
  PWM_MOTOR_SERVO:'M4 35 V13 H13 V35 H25 V13 H34 V35 H44'
 };
 return h('span',{className:'student-subject-icon','aria-hidden':true},h('svg',{viewBox:'0 0 48 48',focusable:false},h('path',{d:paths[system]||paths.LED_GPIO,fill:'none',stroke:'currentColor',strokeWidth:2,strokeLinecap:'round',strokeLinejoin:'round'})));
}
function LearningJourney({practice=false}) {
 const h=React.createElement;
 return h('ol',{className:'student-journey','aria-label':practice?'How subject practice works':'Your learning journey'},...(practice?[
  ['01','Pick a subject','Use a recommendation or choose what interests you.'],
  ['02','Answer 3 questions','Get explanations for the ideas you missed.'],
  ['03','Try your next activity','Reading and experiments adapt to your answers.']
 ]:[
  ['01','Find your starting point','An optional 18-question check across six subjects.'],
  ['02','Learn by doing','Read a short lesson and try the related experiment.'],
  ['03','Check and progress','Practise a subject to refresh your suggestions.']
 ]).map(([n,title,body])=>h('li',{key:n},h('span',{className:'student-step-number','aria-hidden':true},n),h('div',{},h('strong',{},title),h('p',{},body)))));
}
function WorkbenchFirstSteps({p,output,stale,run,check,disabled}) {
 const h=React.createElement,lab=ProgrammableLib.EXPERIMENTS[p.task],isBlink=p.task==='LED';
 return h('details',{className:'student-workbench-guide'},h('summary',{},'New to circuits? Follow your first experiment'),h('div',{className:'student-workbench-steps'},
  h('section',{},h('span',{className:'student-step-number'},'01'),h('h3',{},'Explore the connections'),h('p',{},isBlink?'Trace the board output through the resistor and LED, then back to GND. Click two pins to add a wire.':lab?.aim||'Trace the signal and ground connections. Drag parts to arrange the circuit; crossing wires are not connected.'),h('button',{type:'button',className:'btn btn-default',onClick:check,disabled},'Check wiring')),
  h('section',{},h('span',{className:'student-step-number'},'02'),h('h3',{},'Run the example'),h('p',{},'The example already includes code and wiring. Compile & Run prepares the firmware automatically; Pico uses Run.'),h('button',{type:'button',className:'btn btn-primary',onClick:run,disabled},'Run this example')),
  h('section',{},h('span',{className:'student-step-number'},'03'),h('h3',{},'Change one thing'),h('p',{},isBlink?'Change both 200 ms delays to 100 ms, then run again. Expect about 5 flashes per second instead of 2.5.':lab?.try||'Change one setting or connection, run again and compare the two captures below.'),h('p',{className:'student-guide-state'},output?(stale?'Your circuit changed. Run again before saving this result.':'A capture is available. Inspect the readings below, then save your result.'):'After a run, inspect serial output, readings and signals below the canvas.'))));
}
